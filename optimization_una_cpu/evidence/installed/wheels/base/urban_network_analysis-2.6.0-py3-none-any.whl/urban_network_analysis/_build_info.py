# Auto-generated at build time by hatch_build.py — do not edit.
__commit_date__ = "2026-09-25"
